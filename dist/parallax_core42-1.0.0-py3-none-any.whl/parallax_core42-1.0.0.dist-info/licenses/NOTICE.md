# Notice

Copyright © 2026 Russell Parrish. All rights reserved unless and until a separate
license file is added by the copyright holder.

This packet is prepared as a clean research-software release candidate. No open-source
license has yet been selected. Public redistribution, package-registry publication,
or third-party incorporation should wait for an explicit license decision.

The software is provided for research verification and is not a medical device. It
comes with no diagnostic, prognostic, clinical, or fitness-for-purpose warranty.
